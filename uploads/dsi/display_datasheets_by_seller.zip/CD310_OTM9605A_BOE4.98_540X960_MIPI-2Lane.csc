/*
IC:OTM9605A
LCD:BOE4.98
Resolution:540*960
Interface:MIPI-2lane
Date:2025-08-10
*/

[project name]
BOE4.98_OTM9605A

[lcd type]
MIPI
reset=high
delay 50
reset=low
delay 120
reset=high
delay 60

[backlight]
40mA

[LCD parameter]
pix clock: 30	
horizontal resolution: 540
vertical resolution:   960

horizontal back porch: 32
horizontal front porch:32	
horizontal sync pulse width:4	

vertical back porch: 15
vertical front porch: 16
vertical sync pulse width:1

[MIPI setting]
MIPI lane:2
MIPI speed:444 Mbps


[LCD initial code]
///////OTM9605A+BOE4.98//////////////
		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x00);

		GP_COMMAD_PA(4);
		SPI_WriteData(0xFF);SPI_WriteData(0x96);SPI_WriteData(0x05);SPI_WriteData(0x01);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x80);

		GP_COMMAD_PA(3);
		SPI_WriteData(0xFF);SPI_WriteData(0x96);SPI_WriteData(0x05);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x92);

		GP_COMMAD_PA(3);
		SPI_WriteData(0xFF);SPI_WriteData(0x10);SPI_WriteData(0x02);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xB4);

		GP_COMMAD_PA(2);
		SPI_WriteData(0xC0);SPI_WriteData(0x50);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x89);

		GP_COMMAD_PA(2);
		SPI_WriteData(0xC0);SPI_WriteData(0x01);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xA0);

		GP_COMMAD_PA(2);
		SPI_WriteData(0xC1);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x00);

		GP_COMMAD_PA(2);
		SPI_WriteData(0xA0);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xA2);

		GP_COMMAD_PA(4);
		SPI_WriteData(0xC0);SPI_WriteData(0x01);SPI_WriteData(0x10);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x91);

		GP_COMMAD_PA(2);
		SPI_WriteData(0xC5);SPI_WriteData(0x77);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x80);

		GP_COMMAD_PA(2);
		SPI_WriteData(0xD6);SPI_WriteData(0x58);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x00);

		GP_COMMAD_PA(2);
		SPI_WriteData(0xD7);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x00);

		GP_COMMAD_PA(3);
		SPI_WriteData(0xD8);SPI_WriteData(0x6f);SPI_WriteData(0x6f);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x00);

		GP_COMMAD_PA(2);
		SPI_WriteData(0xD9);SPI_WriteData(0x2A);

		////////////// CE improve code ///////////////////


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x80);

		GP_COMMAD_PA(3);
		SPI_WriteData(0xC1);SPI_WriteData(0x36);SPI_WriteData(0x66);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xb1);

		GP_COMMAD_PA(2);
		SPI_WriteData(0xC5);SPI_WriteData(0x28);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xB2);

		GP_COMMAD_PA(5);
		SPI_WriteData(0xF5);SPI_WriteData(0x15);SPI_WriteData(0x00);SPI_WriteData(0x15);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xC0);

		GP_COMMAD_PA(2);
		SPI_WriteData(0xC5);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x88);

		GP_COMMAD_PA(2);
		SPI_WriteData(0xC4);SPI_WriteData(0x01);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xA2);

		GP_COMMAD_PA(4);
		SPI_WriteData(0xC0);SPI_WriteData(0x20);SPI_WriteData(0x18);SPI_WriteData(0x09);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x80);

		GP_COMMAD_PA(2);
		SPI_WriteData(0xC4);SPI_WriteData(0x9C);
		////////////// CE improve code end ///////////////


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x00);

		GP_COMMAD_PA(17);
		SPI_WriteData(0xE1);SPI_WriteData(0x00);SPI_WriteData(0x0F);SPI_WriteData(0x15);SPI_WriteData(0x0E);
		SPI_WriteData(0x07);SPI_WriteData(0x0E);SPI_WriteData(0x0B);SPI_WriteData(0x09);SPI_WriteData(0x04);
		SPI_WriteData(0x08);SPI_WriteData(0x0F);SPI_WriteData(0x0A);SPI_WriteData(0x11);SPI_WriteData(0x12);
		SPI_WriteData(0x0A);SPI_WriteData(0x03);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x00);

		GP_COMMAD_PA(17);
		SPI_WriteData(0xE2);SPI_WriteData(0x00);SPI_WriteData(0x0F);SPI_WriteData(0x15);SPI_WriteData(0x0E);
		SPI_WriteData(0x07);SPI_WriteData(0x0E);SPI_WriteData(0x0B);SPI_WriteData(0x09);SPI_WriteData(0x04);
		SPI_WriteData(0x08);SPI_WriteData(0x0F);SPI_WriteData(0x0A);SPI_WriteData(0x11);SPI_WriteData(0x12);
		SPI_WriteData(0x0A);SPI_WriteData(0x03);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x80);

		GP_COMMAD_PA(11);
		SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x90);

		GP_COMMAD_PA(16);
		SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xA0);

		GP_COMMAD_PA(16);
		SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xB0);

		GP_COMMAD_PA(11);
		SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xC0);

		GP_COMMAD_PA(16);
		SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x04);SPI_WriteData(0x04);
		SPI_WriteData(0x04);SPI_WriteData(0x04);SPI_WriteData(0x04);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xD0);

		GP_COMMAD_PA(16);
		SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x04);SPI_WriteData(0x04);
		SPI_WriteData(0x04);SPI_WriteData(0x04);SPI_WriteData(0x04);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xE0);

		GP_COMMAD_PA(11);
		SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xF0);

		GP_COMMAD_PA(11);
		SPI_WriteData(0xCB);SPI_WriteData(0xff);SPI_WriteData(0xff);SPI_WriteData(0xff);SPI_WriteData(0xff);
		SPI_WriteData(0xff);SPI_WriteData(0xff);SPI_WriteData(0xff);SPI_WriteData(0xff);SPI_WriteData(0xff);
		SPI_WriteData(0xff);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x80);

		GP_COMMAD_PA(11);
		SPI_WriteData(0xCC);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x09);SPI_WriteData(0x0B);
		SPI_WriteData(0x01);SPI_WriteData(0x25);SPI_WriteData(0x26);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x90);

		GP_COMMAD_PA(16);
		SPI_WriteData(0xCC);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x0A);SPI_WriteData(0x0C);
		SPI_WriteData(0x02);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xA0);

		GP_COMMAD_PA(16);
		SPI_WriteData(0xCC);SPI_WriteData(0x25);SPI_WriteData(0x26);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x80);

		GP_COMMAD_PA(13);
		SPI_WriteData(0xCE);SPI_WriteData(0x86);SPI_WriteData(0x01);SPI_WriteData(0x06);SPI_WriteData(0x85);
		SPI_WriteData(0x01);SPI_WriteData(0x06);SPI_WriteData(0x0F);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0x0f);SPI_WriteData(0x00);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x90);

		GP_COMMAD_PA(15);
		SPI_WriteData(0xCE);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);
		SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xA0);

		GP_COMMAD_PA(15);
		SPI_WriteData(0xCE);SPI_WriteData(0x18);SPI_WriteData(0x05);SPI_WriteData(0x03);SPI_WriteData(0xC0);
		SPI_WriteData(0x00);SPI_WriteData(0x06);SPI_WriteData(0x00);SPI_WriteData(0x18);SPI_WriteData(0x04);
		SPI_WriteData(0x03);SPI_WriteData(0xC1);SPI_WriteData(0x00);SPI_WriteData(0x06);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xB0);

		GP_COMMAD_PA(15);
		SPI_WriteData(0xCE);SPI_WriteData(0x18);SPI_WriteData(0x03);SPI_WriteData(0x03);SPI_WriteData(0xC2);
		SPI_WriteData(0x00);SPI_WriteData(0x06);SPI_WriteData(0x00);SPI_WriteData(0x18);SPI_WriteData(0x02);
		SPI_WriteData(0x03);SPI_WriteData(0xC3);SPI_WriteData(0x00);SPI_WriteData(0x06);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xC0);

		GP_COMMAD_PA(15);
		SPI_WriteData(0xCE);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x10);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x10);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xD0);

		GP_COMMAD_PA(15);
		SPI_WriteData(0xCE);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x10);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x10);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x80);

		GP_COMMAD_PA(15);
		SPI_WriteData(0xCF);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x10);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x10);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x90);

		GP_COMMAD_PA(15);
		SPI_WriteData(0xCF);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x10);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x10);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xA0);

		GP_COMMAD_PA(15);
		SPI_WriteData(0xCF);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x10);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x10);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xB0);

		GP_COMMAD_PA(15);
		SPI_WriteData(0xCF);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x10);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);
		SPI_WriteData(0x00);SPI_WriteData(0x10);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0xC0);

		GP_COMMAD_PA(11);
		SPI_WriteData(0xCF);SPI_WriteData(0x02);SPI_WriteData(0x02);SPI_WriteData(0x10);SPI_WriteData(0x10);
		SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x01);SPI_WriteData(0x81);SPI_WriteData(0x00);
		SPI_WriteData(0x08);


		GP_COMMAD_PA(2);
		SPI_WriteData(0x00);SPI_WriteData(0x00);

		GP_COMMAD_PA(4);
		SPI_WriteData(0xFF);SPI_WriteData(0xFF);SPI_WriteData(0xFF);SPI_WriteData(0xFF);


//Sleep Out
GP_COMMAD_PA(1);SPI_WriteData(0x11);
delay_ms(120);
GP_COMMAD_PA(1);SPI_WriteData(0x29);
delay_ms(50); 