/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "image.h"
#include <string.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define LCD_FRAME_BUFFER 0x200D0000
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

DMA2D_HandleTypeDef hdma2d;

DSI_HandleTypeDef hdsi;

LTDC_HandleTypeDef hltdc;

TIM_HandleTypeDef htim1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void PeriphCommonClock_Config(void);
static void SystemPower_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA2D_Init(void);
static void MX_DSIHOST_DSI_Init(void);
static void MX_LTDC_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE BEGIN 0 */

/* ---------------------------------------------------------------
 * OTM9605A vendor init sequence helper
 * Mimics GP_COMMAD_PA(n) / SPI_WriteData(b) interface so the
 * seller's init sequence can be copy-pasted verbatim.
 *
 * Usage:
 *   GP_COMMAD_PA(2);
 *   SPI_WriteData(0x00); SPI_WriteData(0x80);
 *
 * Internally buffers bytes and flushes via HAL_DSI_LongWrite when
 * the count declared by GP_COMMAD_PA is satisfied.
 * --------------------------------------------------------------- */

static DSI_HandleTypeDef *_dsi_handle = NULL;
static uint8_t  _cmd_buf[64];   /* max vendor command length seen is ~42 bytes */
static uint32_t _cmd_len = 0;   /* total bytes expected (from GP_COMMAD_PA)    */
static uint32_t _cmd_idx = 0;   /* bytes collected so far                      */

/**
 * @brief  Declare the start of a DSI command and how many bytes follow.
 * @param  n  Total number of bytes in this command (including the register byte).
 */
static void GP_COMMAD_PA(uint32_t n)
{
    /* Sanity: if previous command wasn't flushed, flush it now */
    if (_cmd_idx > 0 && _dsi_handle != NULL)
    {
        /* shouldn't happen with correct vendor sequences, but guard anyway */
        HAL_DSI_LongWrite(_dsi_handle, 0, DSI_DCS_LONG_PKT_WRITE,
                          _cmd_idx, _cmd_buf[0],
                          (_cmd_idx > 1) ? &_cmd_buf[1] : NULL);
    }
    _cmd_len = n;
    _cmd_idx = 0;
}

/**
 * @brief  Queue one data byte. Flushes the DSI write when GP_COMMAD_PA count is met.
 * @param  data  Byte to queue.
 */
static void SPI_WriteData(uint8_t data)
{
    if (_cmd_idx >= sizeof(_cmd_buf))
        return; /* overflow guard */

    _cmd_buf[_cmd_idx++] = data;

    if (_cmd_idx == _cmd_len)
    {
        /* All bytes collected — send */
        if (_cmd_len == 1)
        {
            /* Single byte: use short write with no parameter */
            HAL_DSI_ShortWrite(_dsi_handle, 0,
                               DSI_DCS_SHORT_PKT_WRITE_P0,
                               _cmd_buf[0], 0x00);
        }
        else if (_cmd_len == 2)
        {
            /* Two bytes: short write with one parameter */
            HAL_DSI_ShortWrite(_dsi_handle, 0,
                               DSI_DCS_SHORT_PKT_WRITE_P1,
                               _cmd_buf[0], _cmd_buf[1]);
        }
        else
        {
            /* Three or more bytes: long write
             * _cmd_buf[0] = register/command byte (Param1)
             * _cmd_buf[1..n] = payload (ParametersTable) */
            HAL_DSI_LongWrite(_dsi_handle, 0,
                              DSI_DCS_LONG_PKT_WRITE,
                              _cmd_len,        /* NbParams = total including cmd byte */
                              _cmd_buf[0],     /* Param1   = first byte               */
                              &_cmd_buf[1]);   /* rest of payload                     */
        }

        /* Reset for next command */
        _cmd_len = 0;
        _cmd_idx = 0;
    }
}

/**
 * @brief  Initialize the DSI handle used by GP_COMMAD_PA / SPI_WriteData.
 *         Call this once before the vendor init sequence.
 */
static void vendor_init_begin(DSI_HandleTypeDef *hdsi)
{
    _dsi_handle = hdsi;
    _cmd_len    = 0;
    _cmd_idx    = 0;
}

static void OTM9605A_Init(DSI_HandleTypeDef *hdsi) {
	vendor_init_begin(hdsi);

	// init sequence from seller

	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x00);

	GP_COMMAD_PA(4);
	SPI_WriteData(0xFF);SPI_WriteData(0x96);SPI_WriteData(0x05);SPI_WriteData(0x01);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x80);

	GP_COMMAD_PA(3);
	SPI_WriteData(0xFF);SPI_WriteData(0x96);SPI_WriteData(0x05);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x92);

	GP_COMMAD_PA(3);
	SPI_WriteData(0xFF);SPI_WriteData(0x10);SPI_WriteData(0x02);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xB4);

	GP_COMMAD_PA(2);
	SPI_WriteData(0xC0);SPI_WriteData(0x50);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x89);

	GP_COMMAD_PA(2);
	SPI_WriteData(0xC0);SPI_WriteData(0x01);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xA0);

	GP_COMMAD_PA(2);
	SPI_WriteData(0xC1);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
	SPI_WriteData(0xA0);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xA2);

	GP_COMMAD_PA(4);
	SPI_WriteData(0xC0);SPI_WriteData(0x01);SPI_WriteData(0x10);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x91);

	GP_COMMAD_PA(2);
	SPI_WriteData(0xC5);SPI_WriteData(0x77);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x80);

	GP_COMMAD_PA(2);
	SPI_WriteData(0xD6);SPI_WriteData(0x58);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
	SPI_WriteData(0xD7);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x00);

	GP_COMMAD_PA(3);
	SPI_WriteData(0xD8);SPI_WriteData(0x6f);SPI_WriteData(0x6f);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x00);

	GP_COMMAD_PA(2);
	SPI_WriteData(0xD9);SPI_WriteData(0x2A);

	////////////// CE improve code ///////////////////


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x80);

	GP_COMMAD_PA(3);
	SPI_WriteData(0xC1);SPI_WriteData(0x36);SPI_WriteData(0x66);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xb1);

	GP_COMMAD_PA(2);
	SPI_WriteData(0xC5);SPI_WriteData(0x28);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xB2);

	GP_COMMAD_PA(5);
	SPI_WriteData(0xF5);SPI_WriteData(0x15);SPI_WriteData(0x00);SPI_WriteData(0x15);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xC0);

	GP_COMMAD_PA(2);
	SPI_WriteData(0xC5);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x88);

	GP_COMMAD_PA(2);
	SPI_WriteData(0xC4);SPI_WriteData(0x01);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xA2);

	GP_COMMAD_PA(4);
	SPI_WriteData(0xC0);SPI_WriteData(0x20);SPI_WriteData(0x18);SPI_WriteData(0x09);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x80);

	GP_COMMAD_PA(2);
	SPI_WriteData(0xC4);SPI_WriteData(0x9C);
	////////////// CE improve code end ///////////////


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x00);

	GP_COMMAD_PA(17);
	SPI_WriteData(0xE1);SPI_WriteData(0x00);SPI_WriteData(0x0F);SPI_WriteData(0x15);SPI_WriteData(0x0E);
	SPI_WriteData(0x07);SPI_WriteData(0x0E);SPI_WriteData(0x0B);SPI_WriteData(0x09);SPI_WriteData(0x04);
	SPI_WriteData(0x08);SPI_WriteData(0x0F);SPI_WriteData(0x0A);SPI_WriteData(0x11);SPI_WriteData(0x12);
	SPI_WriteData(0x0A);SPI_WriteData(0x03);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x00);

	GP_COMMAD_PA(17);
	SPI_WriteData(0xE2);SPI_WriteData(0x00);SPI_WriteData(0x0F);SPI_WriteData(0x15);SPI_WriteData(0x0E);
	SPI_WriteData(0x07);SPI_WriteData(0x0E);SPI_WriteData(0x0B);SPI_WriteData(0x09);SPI_WriteData(0x04);
	SPI_WriteData(0x08);SPI_WriteData(0x0F);SPI_WriteData(0x0A);SPI_WriteData(0x11);SPI_WriteData(0x12);
	SPI_WriteData(0x0A);SPI_WriteData(0x03);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x80);

	GP_COMMAD_PA(11);
	SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x90);

	GP_COMMAD_PA(16);
	SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xA0);

	GP_COMMAD_PA(16);
	SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xB0);

	GP_COMMAD_PA(11);
	SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xC0);

	GP_COMMAD_PA(16);
	SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x04);SPI_WriteData(0x04);
	SPI_WriteData(0x04);SPI_WriteData(0x04);SPI_WriteData(0x04);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xD0);

	GP_COMMAD_PA(16);
	SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x04);SPI_WriteData(0x04);
	SPI_WriteData(0x04);SPI_WriteData(0x04);SPI_WriteData(0x04);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xE0);

	GP_COMMAD_PA(11);
	SPI_WriteData(0xCB);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xF0);

	GP_COMMAD_PA(11);
	SPI_WriteData(0xCB);SPI_WriteData(0xff);SPI_WriteData(0xff);SPI_WriteData(0xff);SPI_WriteData(0xff);
	SPI_WriteData(0xff);SPI_WriteData(0xff);SPI_WriteData(0xff);SPI_WriteData(0xff);SPI_WriteData(0xff);
	SPI_WriteData(0xff);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x80);

	GP_COMMAD_PA(11);
	SPI_WriteData(0xCC);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x09);SPI_WriteData(0x0B);
	SPI_WriteData(0x01);SPI_WriteData(0x25);SPI_WriteData(0x26);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x90);

	GP_COMMAD_PA(16);
	SPI_WriteData(0xCC);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x0A);SPI_WriteData(0x0C);
	SPI_WriteData(0x02);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xA0);

	GP_COMMAD_PA(16);
	SPI_WriteData(0xCC);SPI_WriteData(0x25);SPI_WriteData(0x26);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x80);

	GP_COMMAD_PA(13);
	SPI_WriteData(0xCE);SPI_WriteData(0x86);SPI_WriteData(0x01);SPI_WriteData(0x06);SPI_WriteData(0x85);
	SPI_WriteData(0x01);SPI_WriteData(0x06);SPI_WriteData(0x0F);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0x0f);SPI_WriteData(0x00);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x90);

	GP_COMMAD_PA(15);
	SPI_WriteData(0xCE);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);
	SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xA0);

	GP_COMMAD_PA(15);
	SPI_WriteData(0xCE);SPI_WriteData(0x18);SPI_WriteData(0x05);SPI_WriteData(0x03);SPI_WriteData(0xC0);
	SPI_WriteData(0x00);SPI_WriteData(0x06);SPI_WriteData(0x00);SPI_WriteData(0x18);SPI_WriteData(0x04);
	SPI_WriteData(0x03);SPI_WriteData(0xC1);SPI_WriteData(0x00);SPI_WriteData(0x06);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xB0);

	GP_COMMAD_PA(15);
	SPI_WriteData(0xCE);SPI_WriteData(0x18);SPI_WriteData(0x03);SPI_WriteData(0x03);SPI_WriteData(0xC2);
	SPI_WriteData(0x00);SPI_WriteData(0x06);SPI_WriteData(0x00);SPI_WriteData(0x18);SPI_WriteData(0x02);
	SPI_WriteData(0x03);SPI_WriteData(0xC3);SPI_WriteData(0x00);SPI_WriteData(0x06);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xC0);

	GP_COMMAD_PA(15);
	SPI_WriteData(0xCE);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x10);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x10);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xD0);

	GP_COMMAD_PA(15);
	SPI_WriteData(0xCE);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x10);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x10);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x80);

	GP_COMMAD_PA(15);
	SPI_WriteData(0xCF);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x10);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x10);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x90);

	GP_COMMAD_PA(15);
	SPI_WriteData(0xCF);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x10);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x10);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xA0);

	GP_COMMAD_PA(15);
	SPI_WriteData(0xCF);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x10);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x10);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xB0);

	GP_COMMAD_PA(15);
	SPI_WriteData(0xCF);SPI_WriteData(0xF0);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x10);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0xF0);SPI_WriteData(0x00);
	SPI_WriteData(0x00);SPI_WriteData(0x10);SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x00);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0xC0);

	GP_COMMAD_PA(11);
	SPI_WriteData(0xCF);SPI_WriteData(0x02);SPI_WriteData(0x02);SPI_WriteData(0x10);SPI_WriteData(0x10);
	SPI_WriteData(0x00);SPI_WriteData(0x00);SPI_WriteData(0x01);SPI_WriteData(0x81);SPI_WriteData(0x00);
	SPI_WriteData(0x08);


	GP_COMMAD_PA(2);
	SPI_WriteData(0x00);SPI_WriteData(0x00);

	GP_COMMAD_PA(4);
	SPI_WriteData(0xFF);SPI_WriteData(0xFF);SPI_WriteData(0xFF);SPI_WriteData(0xFF);

	//Sleep Out
	GP_COMMAD_PA(1);SPI_WriteData(0x11);
	HAL_Delay(120);
	GP_COMMAD_PA(1);SPI_WriteData(0x29);
	HAL_Delay(50);

}

void copy_image_to_fb(uint8_t *fb,
                      const uint32_t *image,
                      int width,
                      int height)
{
    for (int y = 0; y < height; y++)
    {
        for (int x = 0; x < width; x++)
        {
            uint32_t offset = (y * width + x) * 3;
            uint32_t pixel = image[y * width + x];

            uint8_t r = (pixel >> 16) & 0xFF;
            uint8_t g = (pixel >> 8)  & 0xFF;
            uint8_t b = pixel & 0xFF;

            fb[offset + 0] = b;
            fb[offset + 1] = g;
            fb[offset + 2] = r;
        }
    }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the System Power */
  SystemPower_Config();

  /* Configure the system clock */
  SystemClock_Config();

  /* Configure the peripherals common clocks */
  PeriphCommonClock_Config();

  /* USER CODE BEGIN SysInit */
  uint8_t *fb = (uint8_t *)LCD_FRAME_BUFFER;

//  for (int y = 0; y < 960; y++)
//  {
//      uint8_t r, g, b;
//
//      if      (y < 240) { r = 0xFF; g = 0x00; b = 0x00; }  /* Red   */
//      else if (y < 480) { r = 0x00; g = 0xFF; b = 0x00; }  /* Green */
//      else if (y < 720) { r = 0x00; g = 0x00; b = 0xFF; }  /* Blue  */
//      else              { r = 0xFF; g = 0xFF; b = 0xFF; }  /* White */
//
//      for (int x = 0; x < 540; x++)
//      {
//          uint32_t offset = (y * 540 + x) * 3;
//          fb[offset + 0] = r;
//          fb[offset + 1] = g;
//          fb[offset + 2] = b;
//      }
//  }
  copy_image_to_fb(
      fb,
      image_file,
      540,
      960
  );

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA2D_Init();
  MX_DSIHOST_DSI_Init();
  MX_LTDC_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */

  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_3, 1000);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMBOOST = RCC_PLLMBOOST_DIV2;
  RCC_OscInitStruct.PLL.PLLM = 2;
  RCC_OscInitStruct.PLL.PLLN = 25;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLLVCIRANGE_1;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_PCLK3;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief Peripherals Common Clock Configuration
  * @retval None
  */
void PeriphCommonClock_Config(void)
{
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the common periph clock
  */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_LTDC|RCC_PERIPHCLK_DSI;
  PeriphClkInit.DsiClockSelection = RCC_DSICLKSOURCE_PLL3;
  PeriphClkInit.LtdcClockSelection = RCC_LTDCCLKSOURCE_PLL3;
  PeriphClkInit.PLL3.PLL3Source = RCC_PLLSOURCE_HSE;
  PeriphClkInit.PLL3.PLL3M = 2;
  PeriphClkInit.PLL3.PLL3N = 20;
  PeriphClkInit.PLL3.PLL3P = 6;
  PeriphClkInit.PLL3.PLL3Q = 2;
  PeriphClkInit.PLL3.PLL3R = 8;
  PeriphClkInit.PLL3.PLL3RGE = RCC_PLLVCIRANGE_1;
  PeriphClkInit.PLL3.PLL3FRACN = 0;
  PeriphClkInit.PLL3.PLL3ClockOut = RCC_PLL3_DIVP|RCC_PLL3_DIVR;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief Power Configuration
  * @retval None
  */
static void SystemPower_Config(void)
{

  /*
   * Switch to SMPS regulator instead of LDO
   */
  if (HAL_PWREx_ConfigSupply(PWR_SMPS_SUPPLY) != HAL_OK)
  {
    Error_Handler();
  }
/* USER CODE BEGIN PWR */
/* USER CODE END PWR */
}

/**
  * @brief DMA2D Initialization Function
  * @param None
  * @retval None
  */
static void MX_DMA2D_Init(void)
{

  /* USER CODE BEGIN DMA2D_Init 0 */

  /* USER CODE END DMA2D_Init 0 */

  /* USER CODE BEGIN DMA2D_Init 1 */

  /* USER CODE END DMA2D_Init 1 */
  hdma2d.Instance = DMA2D;
  hdma2d.Init.Mode = DMA2D_M2M;
  hdma2d.Init.ColorMode = DMA2D_OUTPUT_ARGB8888;
  hdma2d.Init.OutputOffset = 0;
  hdma2d.Init.BytesSwap = DMA2D_BYTES_REGULAR;
  hdma2d.Init.LineOffsetMode = DMA2D_LOM_PIXELS;
  hdma2d.LayerCfg[1].InputOffset = 0;
  hdma2d.LayerCfg[1].InputColorMode = DMA2D_INPUT_ARGB8888;
  hdma2d.LayerCfg[1].AlphaMode = DMA2D_NO_MODIF_ALPHA;
  hdma2d.LayerCfg[1].InputAlpha = 0;
  hdma2d.LayerCfg[1].AlphaInverted = DMA2D_REGULAR_ALPHA;
  hdma2d.LayerCfg[1].RedBlueSwap = DMA2D_RB_REGULAR;
  if (HAL_DMA2D_Init(&hdma2d) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_DMA2D_ConfigLayer(&hdma2d, 1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DMA2D_Init 2 */

  /* USER CODE END DMA2D_Init 2 */

}

/**
  * @brief DSIHOST Initialization Function
  * @param None
  * @retval None
  */
static void MX_DSIHOST_DSI_Init(void)
{

  /* USER CODE BEGIN DSIHOST_Init 0 */

  /* USER CODE END DSIHOST_Init 0 */

  DSI_PLLInitTypeDef PLLInit = {0};
  DSI_HOST_TimeoutTypeDef HostTimeouts = {0};
  DSI_PHY_TimerTypeDef PhyTimings = {0};
  DSI_VidCfgTypeDef VidCfg = {0};

  /* USER CODE BEGIN DSIHOST_Init 1 */

  /* USER CODE END DSIHOST_Init 1 */
  hdsi.Instance = DSI;
  hdsi.Init.AutomaticClockLaneControl = DSI_AUTO_CLK_LANE_CTRL_DISABLE;
  hdsi.Init.TXEscapeCkdiv = 4;
  hdsi.Init.NumberOfLanes = DSI_TWO_DATA_LANES;
  hdsi.Init.PHYFrequencyRange = DSI_DPHY_FRANGE_450MHZ_510MHZ;
  hdsi.Init.PHYLowPowerOffset = PHY_LP_OFFSSET_0_CLKP;
  PLLInit.PLLNDIV = 19;
  PLLInit.PLLIDF = DSI_PLL_IN_DIV1;
  PLLInit.PLLODF = DSI_PLL_OUT_DIV2;
  PLLInit.PLLVCORange = DSI_DPHY_VCO_FRANGE_800MHZ_1GHZ;
  PLLInit.PLLChargePump = DSI_PLL_CHARGE_PUMP_2000HZ_4400HZ;
  PLLInit.PLLTuning = DSI_PLL_LOOP_FILTER_2000HZ_4400HZ;
  if (HAL_DSI_Init(&hdsi, &PLLInit) != HAL_OK)
  {
    Error_Handler();
  }
  HostTimeouts.TimeoutCkdiv = 1;
  HostTimeouts.HighSpeedTransmissionTimeout = 0;
  HostTimeouts.LowPowerReceptionTimeout = 0;
  HostTimeouts.HighSpeedReadTimeout = 0;
  HostTimeouts.LowPowerReadTimeout = 0;
  HostTimeouts.HighSpeedWriteTimeout = 0;
  HostTimeouts.HighSpeedWritePrespMode = DSI_HS_PM_DISABLE;
  HostTimeouts.LowPowerWriteTimeout = 0;
  HostTimeouts.BTATimeout = 0;
  if (HAL_DSI_ConfigHostTimeouts(&hdsi, &HostTimeouts) != HAL_OK)
  {
    Error_Handler();
  }
  PhyTimings.ClockLaneHS2LPTime = 11;
  PhyTimings.ClockLaneLP2HSTime = 40;
  PhyTimings.DataLaneHS2LPTime = 12;
  PhyTimings.DataLaneLP2HSTime = 23;
  PhyTimings.DataLaneMaxReadTime = 0;
  PhyTimings.StopWaitTime = 7;
  if (HAL_DSI_ConfigPhyTimer(&hdsi, &PhyTimings) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_DSI_ConfigFlowControl(&hdsi, DSI_FLOW_CONTROL_BTA) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_DSI_ConfigErrorMonitor(&hdsi, HAL_DSI_ERROR_NONE) != HAL_OK)
  {
    Error_Handler();
  }
  VidCfg.ColorCoding = DSI_RGB888;
  VidCfg.LooselyPacked = DSI_LOOSELY_PACKED_DISABLE;
  VidCfg.Mode = DSI_VID_MODE_BURST;
  VidCfg.PacketSize = 540;
  VidCfg.NumberOfChunks = 0;
  VidCfg.NullPacketSize = 0;
  VidCfg.HSPolarity = DSI_HSYNC_ACTIVE_LOW;
  VidCfg.VSPolarity = DSI_VSYNC_ACTIVE_LOW;
  VidCfg.DEPolarity = DSI_DATA_ENABLE_ACTIVE_HIGH;
  VidCfg.HorizontalSyncActive = 4;
  VidCfg.HorizontalBackPorch = 32;
  VidCfg.HorizontalLine = 1156;
  VidCfg.VerticalSyncActive = 1;
  VidCfg.VerticalBackPorch = 15;
  VidCfg.VerticalFrontPorch = 16;
  VidCfg.VerticalActive = 960;
  VidCfg.LPCommandEnable = DSI_LP_COMMAND_ENABLE;
  VidCfg.LPLargestPacketSize = 4;
  VidCfg.LPVACTLargestPacketSize = 0;
  VidCfg.LPHorizontalFrontPorchEnable = DSI_LP_HFP_ENABLE;
  VidCfg.LPHorizontalBackPorchEnable = DSI_LP_HBP_ENABLE;
  VidCfg.LPVerticalActiveEnable = DSI_LP_VACT_DISABLE;
  VidCfg.LPVerticalFrontPorchEnable = DSI_LP_VFP_ENABLE;
  VidCfg.LPVerticalBackPorchEnable = DSI_LP_VBP_ENABLE;
  VidCfg.LPVerticalSyncActiveEnable = DSI_LP_VSYNC_ENABLE;
  VidCfg.FrameBTAAcknowledgeEnable = DSI_FBTAA_DISABLE;
  if (HAL_DSI_ConfigVideoMode(&hdsi, &VidCfg) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_DSI_SetGenericVCID(&hdsi, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DSIHOST_Init 2 */

  /* Step 1: Start DSI — activates lanes */
  if (HAL_DSI_Start(&hdsi) != HAL_OK) { Error_Handler(); }   // FIXED: was missing

  /* Step 2: Switch clock source from PLL3 to DSIPHY — CRITICAL */
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_DSI;
  PeriphClkInit.DsiClockSelection    = RCC_DSICLKSOURCE_DSIPHY;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK) { Error_Handler(); }

  // lcd reset
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_SET);
  HAL_Delay(50);
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_RESET);
  HAL_Delay(120);
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_SET);
  HAL_Delay(60);

  /* USER CODE END DSIHOST_Init 2 */

}

/**
  * @brief LTDC Initialization Function
  * @param None
  * @retval None
  */
static void MX_LTDC_Init(void)
{

  /* USER CODE BEGIN LTDC_Init 0 */

	#define PANEL_HSW   4
	#define PANEL_HBP   32
	#define PANEL_HFP   32
	#define PANEL_HACT  540
	#define PANEL_VSW   1
	#define PANEL_VBP   15
	#define PANEL_VFP   16
	#define PANEL_VACT  960

	/*
hltdc.Init.HorizontalSync    = PANEL_HSW - 1;                                    // 3
hltdc.Init.VerticalSync      = PANEL_VSW - 1;                                    // 0
hltdc.Init.AccumulatedHBP    = PANEL_HSW + PANEL_HBP - 1;                        // 35
hltdc.Init.AccumulatedVBP    = PANEL_VSW + PANEL_VBP - 1;                        // 15
hltdc.Init.AccumulatedActiveW = PANEL_HSW + PANEL_HBP + PANEL_HACT - 1;          // 575
hltdc.Init.AccumulatedActiveH = PANEL_VSW + PANEL_VBP + PANEL_VACT - 1;          // 975
hltdc.Init.TotalWidth        = PANEL_HSW + PANEL_HBP + PANEL_HACT + PANEL_HFP - 1; // 607
hltdc.Init.TotalHeigh        = PANEL_VSW + PANEL_VBP + PANEL_VACT + PANEL_VFP - 1; // 991
	 */
  /* USER CODE END LTDC_Init 0 */

  LTDC_LayerCfgTypeDef pLayerCfg = {0};

  /* USER CODE BEGIN LTDC_Init 1 */

  /* USER CODE END LTDC_Init 1 */
  hltdc.Instance = LTDC;
  hltdc.Init.HSPolarity = LTDC_HSPOLARITY_AL;
  hltdc.Init.VSPolarity = LTDC_VSPOLARITY_AL;
  hltdc.Init.DEPolarity = LTDC_DEPOLARITY_AL;
  hltdc.Init.PCPolarity = LTDC_PCPOLARITY_IPC;
  hltdc.Init.HorizontalSync    = PANEL_HSW - 1;                                    // 3
  hltdc.Init.VerticalSync      = PANEL_VSW - 1;                                    // 0
  hltdc.Init.AccumulatedHBP    = PANEL_HSW + PANEL_HBP - 1;                        // 35
  hltdc.Init.AccumulatedVBP    = PANEL_VSW + PANEL_VBP - 1;                        // 15
  hltdc.Init.AccumulatedActiveW = PANEL_HSW + PANEL_HBP + PANEL_HACT - 1;          // 575
  hltdc.Init.AccumulatedActiveH = PANEL_VSW + PANEL_VBP + PANEL_VACT - 1;          // 975
  hltdc.Init.TotalWidth        = PANEL_HSW + PANEL_HBP + PANEL_HACT + PANEL_HFP - 1; // 607
  hltdc.Init.TotalHeigh        = PANEL_VSW + PANEL_VBP + PANEL_VACT + PANEL_VFP - 1; // 991
  hltdc.Init.Backcolor.Blue = 0;
  hltdc.Init.Backcolor.Green = 0;
  hltdc.Init.Backcolor.Red = 0;
  if (HAL_LTDC_Init(&hltdc) != HAL_OK)
  {
    Error_Handler();
  }
  pLayerCfg.WindowX0 = 0;
  pLayerCfg.WindowX1 = 540;
  pLayerCfg.WindowY0 = 0;
  pLayerCfg.WindowY1 = 960;
  pLayerCfg.PixelFormat = LTDC_PIXEL_FORMAT_RGB888;
  pLayerCfg.Alpha = 0xFF;
  pLayerCfg.Alpha0 = 0;
  pLayerCfg.BlendingFactor1 = LTDC_BLENDING_FACTOR1_CA;
  pLayerCfg.BlendingFactor2 = LTDC_BLENDING_FACTOR2_CA;
  pLayerCfg.FBStartAdress = 0x200D0000;
  pLayerCfg.ImageWidth = 540;
  pLayerCfg.ImageHeight = 960;
  pLayerCfg.Backcolor.Blue = 0;
  pLayerCfg.Backcolor.Green = 0;
  pLayerCfg.Backcolor.Red = 0;
  if (HAL_LTDC_ConfigLayer(&hltdc, &pLayerCfg, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN LTDC_Init 2 */
  // fixme: pLayerCfg.FBStartAdress = LCD_FRAME_BUFFER
  OTM9605A_Init(&hdsi);

  /* USER CODE END LTDC_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 7499;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 3750;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.BreakAFMode = TIM_BREAK_AFMODE_INPUT;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.Break2AFMode = TIM_BREAK_AFMODE_INPUT;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC15 */
  GPIO_InitStruct.Pin = GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
