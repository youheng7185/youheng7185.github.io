#ifndef IMAGE_H
#define IMAGE_H

#include <stdint.h>

extern const uint32_t image_file[];

#endif